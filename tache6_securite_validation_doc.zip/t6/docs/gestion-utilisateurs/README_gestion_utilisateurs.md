# WELLUP — Module « Gestion des utilisateurs »

CRUD des utilisateurs, rôles (user / admin), sessions et sécurité — PHP, architecture MVC.
À relier depuis le `README.md` principal du dépôt.

## Fonctionnalités
- **Create** : inscription (`?action=register`), mot de passe haché (`password_hash`).
- **Read** : espace utilisateur, profil (`?action=profile`), liste de tous les comptes (backoffice).
- **Update** : l'utilisateur modifie son profil (`?action=edit_profile`) ; l'admin modifie un compte et son rôle (`?action=admin_edit_user&id=…`).
- **Delete** : l'admin supprime un compte (`?action=admin_delete_user`, POST + confirmation).
- Changement du mot de passe par l'utilisateur (`?action=change_password`, ancien mot de passe exigé).
- Connexion / déconnexion (POST + jeton CSRF), expiration de session après 30 minutes d'inactivité.
- Frontoffice (rôle `user`) et backoffice (rôle `admin`), interfaces visuellement distinctes.

## Règles métier
- Le rôle est toujours forcé à `user` à l'inscription.
- Un admin ne peut pas supprimer son propre compte.
- Le dernier administrateur ne peut être ni supprimé ni rétrogradé.
- Le rôle est relu en base à chaque page d'administration (un compte rétrogradé ou supprimé perd l'accès immédiatement).
- Un utilisateur ne voit et ne modifie que son propre compte (l'identifiant vient de la session, jamais de l'URL).

## Structure
```
app/
├── Controllers/AuthController.php   logique : SQL, sessions, CSRF, rôles
├── Models/UserModel.php             entité utilisateur (attributs, getters/setters, fromArray)
├── config/database.php              connexion PDO (Singleton)
├── Views/utilisateurs/              vues et layouts (frontoffice + backoffice)
└── user_routes.php                  routage ?action=
assets/ (css, js, images)  ·  sql/users.sql  ·  docs/
```

## Installation, configuration, exécution
1. Installer XAMPP, démarrer **Apache** et **MySQL**.
2. Placer le dépôt dans `C:\xampp\htdocs\<nom-du-depot>`.
3. phpMyAdmin : créer la base (ex. `wellup`, `utf8mb4_unicode_ci`) puis importer `sql/users.sql`.
4. Adapter si besoin `app/config/database.php` (hôte, nom de base, utilisateur, mot de passe).
5. Ouvrir `http://localhost/<nom-du-depot>/index.php?action=register`.
6. Créer un administrateur : s'inscrire, puis dans phpMyAdmin passer `role` à `admin` pour ce compte, se déconnecter et se reconnecter.

## Routes (`index.php?action=…`)
| action | accès | rôle |
|---|---|---|
| register, login | public | inscription, connexion |
| logout | connecté (POST) | déconnexion |
| dashboard, profile, edit_profile, account, change_password | connecté | espace personnel |
| admin, admin_edit_user, admin_delete_user | admin | backoffice (403 sinon) |

## Sécurité mise en place
Requêtes préparées PDO · `password_hash` / `password_verify` · `session_regenerate_id` à la connexion · cookie HttpOnly + SameSite + strict mode · expiration 30 min · jetons CSRF sur tous les formulaires · échappement `htmlspecialchars` en sortie · en-têtes HTTP (X-Frame-Options, nosniff, Referrer-Policy, CSP) · contrôle du rôle côté serveur sur chaque page sensible.

## Validation des saisies
- **Serveur (PHP)** : `AuthController` (format du pseudo, e-mail, longueur du mot de passe, unicité, rôle autorisé).
- **Client (JavaScript)** : `assets/js/validation.js`, appliqué automatiquement aux formulaires d'inscription, de connexion, de modification du profil et d'édition admin.

## Scénarios de test
Inscription (champs vides, e-mail invalide, mot de passe < 8, confirmation différente, doublon) · connexion valide / invalide · accès direct à `?action=dashboard` sans session · bouton « Précédent » après déconnexion · accès `?action=admin` avec un compte `user` (403) · modification et suppression d'un compte par l'admin · suppression de son propre compte et du dernier admin (refus) · injection SQL `' OR '1'='1` · nom d'utilisateur contenant `<script>` · formulaire sans jeton CSRF.

## Déclaration d'usage de l'IA générative
**Outil** : Claude (Anthropic), utilisé comme assistant de programmation.

**Usage** : génération d'une première version du code (modèle, contrôleur, vues, routage, CSS, JavaScript, SQL) à partir du cahier des charges, du workshop « Sessions et Sécurité PHP » et de la structure du dépôt ; explications des étapes Git/GitHub.

**Ce que chaque membre doit compléter avant la validation** (ne cocher que ce qui a réellement été fait) :
- [ ] J'ai lu et compris chaque fonction de `AuthController` et je peux l'expliquer sans aide.
- [ ] J'ai testé tous les scénarios ci-dessus sur ma machine.
- [ ] Modifications personnelles apportées au code généré : _à décrire_
- [ ] Erreurs ou limites du code généré que j'ai repérées et corrigées : _à décrire_
- [ ] Choix de conception que je peux justifier (MVC, requêtes préparées, CSRF, sessions, rôle relu en base) : _à décrire_

Tout code non compris doit être réécrit ou simplifié avant la présentation.

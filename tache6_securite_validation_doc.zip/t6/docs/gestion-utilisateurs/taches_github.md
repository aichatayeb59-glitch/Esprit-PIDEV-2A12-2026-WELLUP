# Tâches GitHub — Module Gestion des utilisateurs

| # | Tâche | Critère de validation / test | État |
|---|-------|------------------------------|------|
| 1 | Table `users` (sql/users.sql) | Table créée dans phpMyAdmin | À faire |
| 2 | `app/config/database.php` (Singleton PDO) | Connexion sans erreur | À faire |
| 3 | `UserModel.php` | Attributs privés, getters/setters, fromArray ; aucune requête SQL | À faire |
| 4 | Inscription (`register()` + vue) | Champs validés, doublon refusé, mot de passe `$2y$` en base | À faire |
| 5 | Connexion (`login()` + vue) | Identifiants valides → espace ; invalides → message générique | À faire |
| 6 | Déconnexion POST + CSRF (`logoutIfValid()`) | Session détruite ; « Précédent » ne rouvre pas les pages protégées | À faire |
| 7 | Profil + modification du profil | Seul le compte connecté est visible/modifiable | À faire |
| 8 | Gestion du compte (`account.php`) | Uniquement les actions validées par l'équipe | À faire |
| 9 | Frontoffice / Backoffice (`requireAuth`, `requireRole`, `syncSession`) | user → dashboard ; admin → admin ; user sur admin → 403 | À faire |
| 10 | CRUD admin : modifier un utilisateur et son rôle | Changements enregistrés ; doublons refusés ; CSRF | À faire |
| 11 | CRUD admin : supprimer un utilisateur | Confirmation ; refus sur son propre compte et le dernier admin | À faire |
| 12 | Validation JavaScript (`validation.js`) | Messages affichés avant l'envoi sur tous les formulaires | À faire |
| 13 | Sécurité sessions (`ini_set` + expiration 30 min) | Cookie HttpOnly ; expiration testée avec 10 s | À faire |
| 14 | Sécurité : SQL, XSS, CSRF, en-têtes HTTP | Tests du workshop (parties 7.2 à 7.5) | À faire |
| 15 | Intégration au dépôt (index.php, template, logo) | Modules de l'équipe toujours fonctionnels | À faire |
| 16 | README du module + déclaration IA | Installation, configuration, exécution ; déclaration complétée | À faire |
| 17 | Commits réguliers + Pull Request + tableau à jour | Contributions individuelles visibles | À faire |
| 18 | Changement du mot de passe (`changePassword()` + vue) | Ancien mot de passe vérifié ; nouveau ≥ 8 caractères ; hash `$2y$` mis à jour | À faire |

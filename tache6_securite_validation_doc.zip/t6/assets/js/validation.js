/**
 * assets/js/validation.js
 * Validation côté client (JavaScript), en complément de la validation PHP côté serveur.
 * S'applique automatiquement à tout formulaire contenant les champs :
 * username, email, password, password_confirm, role.
 */
(function () {
    'use strict';

    var RE_USERNAME = /^[a-zA-Z0-9_\-]{3,50}$/;
    var RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var NAMES = ['username', 'email', 'password', 'password_confirm', 'role',
                 'current_password', 'new_password', 'new_password_confirm'];

    function holderOf(input) {
        return input.closest('.pw') || input;
    }

    function clearError(input) {
        input.classList.remove('input-invalid');
        var next = holderOf(input).nextElementSibling;
        if (next && next.classList.contains('field-error')) {
            next.remove();
        }
    }

    function setError(input, message) {
        clearError(input);
        input.classList.add('input-invalid');
        var p = document.createElement('p');
        p.className = 'field-error';
        p.setAttribute('role', 'alert');
        p.textContent = message;
        holderOf(input).insertAdjacentElement('afterend', p);
    }

    /** Retourne un message d'erreur, ou '' si le champ est valide. */
    function check(form, input) {
        var v = input.value;
        switch (input.name) {
            case 'username':
                v = v.trim();
                if (v === '') return "Le nom d'utilisateur est obligatoire.";
                if (!RE_USERNAME.test(v)) return "3 à 50 caractères : lettres, chiffres, _ ou -.";
                break;
            case 'email':
                v = v.trim();
                if (v === '') return "L'adresse e-mail est obligatoire.";
                if (v.length > 150 || !RE_EMAIL.test(v)) return "Adresse e-mail invalide.";
                break;
            case 'password':
                if (v === '') return "Le mot de passe est obligatoire.";
                // La longueur minimale ne s'applique qu'à l'inscription (présence de la confirmation)
                if (form.elements.password_confirm && v.length < 8) {
                    return "Le mot de passe doit contenir au moins 8 caractères.";
                }
                break;
            case 'password_confirm':
                if (v === '') return "Veuillez confirmer le mot de passe.";
                if (form.elements.password && v !== form.elements.password.value) {
                    return "Les mots de passe ne correspondent pas.";
                }
                break;
            case 'current_password':
                if (v === '') return "Le mot de passe actuel est obligatoire.";
                break;
            case 'new_password':
                if (v === '') return "Le nouveau mot de passe est obligatoire.";
                if (v.length < 8) return "Le nouveau mot de passe doit contenir au moins 8 caractères.";
                if (form.elements.current_password && v === form.elements.current_password.value) {
                    return "Le nouveau mot de passe doit être différent de l'ancien.";
                }
                break;
            case 'new_password_confirm':
                if (v === '') return "Veuillez confirmer le nouveau mot de passe.";
                if (form.elements.new_password && v !== form.elements.new_password.value) {
                    return "Les mots de passe ne correspondent pas.";
                }
                break;
            case 'role':
                if (v !== 'user' && v !== 'admin') return "Rôle invalide.";
                break;
        }
        return '';
    }

    function validateInput(form, input) {
        var message = check(form, input);
        if (message) {
            setError(input, message);
        } else {
            clearError(input);
        }
        return message === '';
    }

    document.querySelectorAll('form').forEach(function (form) {
        var inputs = Array.prototype.filter.call(form.elements, function (el) {
            return NAMES.indexOf(el.name) !== -1;
        });
        if (inputs.length === 0) return;

        // Les messages JS remplacent les bulles natives (le HTML5 reste actif si JS est désactivé)
        form.noValidate = true;

        inputs.forEach(function (input) {
            input.addEventListener('blur', function () { validateInput(form, input); });
            input.addEventListener('input', function () {
                if (input.classList.contains('input-invalid')) validateInput(form, input);
            });
        });

        form.addEventListener('submit', function (event) {
            var firstInvalid = null;
            inputs.forEach(function (input) {
                if (!validateInput(form, input) && !firstInvalid) firstInvalid = input;
            });
            if (firstInvalid) {
                event.preventDefault();
                firstInvalid.focus();
            }
        });
    });
})();

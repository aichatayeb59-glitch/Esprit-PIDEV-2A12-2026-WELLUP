# Tâche 6 — Sécurité transversale, validation JS et documentation

Fichiers propres à la tâche 6 (à copier tels quels dans le dépôt) :
- assets/js/validation.js
- docs/gestion-utilisateurs/README_gestion_utilisateurs.md
- docs/gestion-utilisateurs/taches_github.md

Dossier extraits/ : parties de fichiers PARTAGÉS avec les autres tâches (ne pas écraser ces fichiers, juste les connaître / les commiter pour votre part) :
- AuthController_csrf_lignes_54-70.php : getCsrfToken() et verifyCsrfToken()
- user_routes_entetes_securite_lignes_1-35.php : en-têtes HTTP (X-Frame-Options, nosniff, Referrer-Policy, CSP) + jeton CSRF global
- champs_csrf_dans_les_vues.txt : où le champ caché csrf_token est placé dans chaque formulaire

À faire aussi (tests) : injection SQL, XSS (<script>), formulaire sans jeton CSRF — voir la section "Scénarios de test" du README.

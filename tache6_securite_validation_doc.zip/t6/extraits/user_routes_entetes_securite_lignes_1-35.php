<?php
declare(strict_types=1);

/**
 * app/user_routes.php
 * Routage du module « Gestion des utilisateurs » (index.php?action=...).
 * Inclus par index.php quand le paramètre ?action= est présent.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Expiration de la session après 30 minutes d'inactivité
$sessionLifetime = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $sessionLifetime)) {
    $_SESSION = [];
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

// En-têtes de sécurité (limités aux pages de ce module)
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'");

require_once __DIR__ . '/Controllers/AuthController.php';
$authController = new AuthController();
// Jeton CSRF disponible pour toutes les vues (formulaire de déconnexion, etc.)
$csrfToken = $authController->getCsrfToken();

$action = $_GET['action'] ?? 'home';
$views = __DIR__ . '/Views/utilisateurs/';
